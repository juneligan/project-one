package com.theProjectOne.first.authenticator;

public interface LogoutService {
    void logout(Runnable onSuccess);
}
