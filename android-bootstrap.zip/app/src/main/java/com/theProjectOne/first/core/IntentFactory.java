package com.theProjectOne.first.core;

public class IntentFactory {
    //TODO implement an Activity and Fragment delegate pattern
}
